from Sprite import Sprite
from Bullet import Bullet
from Player import Player
from Shooter import Shooter
import SpriteManager

class SlimeBot(Sprite):
    
    
    diameter = 50
    c = color(127,250,0)
    
    position.x = random(width)
    position.y = random(height)
    
    def move(self):
        angle = 0.0
        for (int i = 0
        
       x = constrain(x, 100, 300)
       y = constrain(y, 100, 300)
       self.xspeed = 
       self.yspeed = 
       angle = TWO_PI/ 
       self.x += self.xspeed 
       self.y += self.yspeed
        
